export interface Error {
    error: boolean;
    message: string;
}